execute positioned ^ ^ ^1 if predicate datapipes_lib:lightning_rod_axis_y run return run function datapipes_lib:require/pipe_presets/lightning_rod/axis_y_on
execute if block ^ ^ ^1 waxed_cut_copper positioned ^ ^ ^1 run return run function datapipes_lib:require/pipe_presets/lightning_rod/corner_on
execute if block ^ ^ ^1 lodestone positioned ^ ^ ^1 run function datapipes_lib:require/pipe_presets/lightning_rod/axis_y_on
