execute if block ~ ~ ~ red_glazed_terracotta run function datapipes_lib:require/pipe_presets/wire/corner_off
