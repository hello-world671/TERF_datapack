execute if block ~ ~ ~ waxed_lightning_rod run setblock ~ ~ ~ waxed_oxidized_copper_chain[axis=z]
execute positioned ^ ^ ^1 if predicate datapipes_lib:lightning_rod_axis_y run return run function datapipes_lib:require/pipe_presets/lightning_rod_convert/axis_y_off
execute if block ^ ^ ^1 red_glazed_terracotta positioned ^ ^ ^1 run return run function datapipes_lib:require/pipe_presets/lightning_rod_convert/corner_off
execute if block ^ ^ ^1 lodestone positioned ^ ^ ^1 run function datapipes_lib:require/pipe_presets/lightning_rod_convert/axis_y_off
