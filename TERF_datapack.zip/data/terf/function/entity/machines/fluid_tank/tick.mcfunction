$execute $(checks)run 
