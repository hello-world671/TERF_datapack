function terf:require/turn_on_dark_oak_button
function terf:require/turn_off_dark_oak_button
