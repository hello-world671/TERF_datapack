particle minecraft:explosion ~ ~ ~ 1 1 1 5 1 force
